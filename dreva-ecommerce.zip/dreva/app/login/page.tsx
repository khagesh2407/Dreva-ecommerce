'use client'
import { useState } from 'react'
import Link from 'next/link'

export default function LoginPage() {
  const [form, setForm] = useState({ email: '', password: '' })

  return (
    <div className="min-h-[80vh] flex items-center justify-center bg-cream-50 px-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <span className="text-4xl block mb-3">🌿</span>
          <h1 className="font-display text-4xl font-light text-forest-900 mb-2">Welcome back</h1>
          <p className="font-body font-light text-forest-500 text-sm">Sign in to your Dreva account</p>
        </div>

        <div className="bg-white border border-cream-200 rounded-sm p-8">
          <form className="space-y-5" onSubmit={e => e.preventDefault()}>
            <div>
              <label className="block text-xs font-body font-medium tracking-widest uppercase text-forest-600 mb-2">Email</label>
              <input type="email" required placeholder="your@email.com" value={form.email}
                onChange={e => setForm({ ...form, email: e.target.value })}
                className="input-field" />
            </div>
            <div>
              <label className="block text-xs font-body font-medium tracking-widest uppercase text-forest-600 mb-2">Password</label>
              <input type="password" required placeholder="••••••••" value={form.password}
                onChange={e => setForm({ ...form, password: e.target.value })}
                className="input-field" />
            </div>
            <div className="flex justify-end">
              <a href="#" className="text-xs font-body text-forest-500 hover:text-forest-800 transition-colors">Forgot password?</a>
            </div>
            <button type="submit" className="btn-primary w-full text-center">Sign In</button>
          </form>

          <div className="mt-6 pt-6 border-t border-cream-100 text-center">
            <p className="text-sm font-body font-light text-forest-500">
              Don&apos;t have an account?{' '}
              <Link href="/register" className="text-forest-700 font-medium hover:text-forest-900 transition-colors">
                Create one →
              </Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
