import HeroSection from '@/components/HeroSection'
import Categories from '@/components/Categories'
import FeaturedProducts from '@/components/FeaturedProducts'
import WhyChooseDreva from '@/components/WhyChooseDreva'
import Newsletter from '@/components/Newsletter'
import { blogPosts } from '@/lib/data'
import Link from 'next/link'
import Image from 'next/image'

export default function HomePage() {
  const recentPosts = blogPosts.slice(0, 3)

  return (
    <>
      <HeroSection />
      <Categories />
      <FeaturedProducts />
      <WhyChooseDreva />

      {/* Blog teaser */}
      <section className="section bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="flex items-end justify-between mb-12">
            <div>
              <p className="text-xs font-body font-medium tracking-[0.3em] uppercase text-forest-500 mb-3">Wellness Insights</p>
              <h2 className="font-display text-4xl sm:text-5xl font-light text-forest-900">From the Blog</h2>
            </div>
            <Link href="/blog" className="hidden sm:inline-flex items-center gap-2 text-sm font-body font-medium text-forest-600 hover:text-forest-900 transition-colors">
              All Articles →
            </Link>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {recentPosts.map(post => (
              <Link key={post.id} href={`/blog/${post.id}`} className="group block product-card rounded-sm overflow-hidden border border-cream-200">
                <div className="relative h-48 overflow-hidden">
                  <Image src={post.image} alt={post.title} fill className="object-cover group-hover:scale-105 transition-transform duration-600" />
                </div>
                <div className="p-5">
                  <div className="flex items-center gap-3 mb-3">
                    <span className="text-[10px] badge bg-forest-100 text-forest-700">{post.category}</span>
                    <span className="text-[10px] text-forest-400 font-body">{post.readTime} read</span>
                  </div>
                  <h3 className="font-display text-xl font-normal text-forest-900 mb-2 leading-snug group-hover:text-forest-700 transition-colors">{post.title}</h3>
                  <p className="text-sm font-body font-light text-forest-500 line-clamp-2">{post.excerpt}</p>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      <Newsletter />

      {/* WhatsApp CTA */}
      <a href="https://wa.me/918224021324?text=Hi%20Dreva!%20I%27d%20like%20to%20know%20more."
        target="_blank" rel="noopener noreferrer"
        className="fixed bottom-6 right-6 z-50 w-14 h-14 bg-green-500 hover:bg-green-600 text-white rounded-full shadow-lg flex items-center justify-center text-2xl transition-all hover:scale-110 hover:shadow-xl">
        <svg viewBox="0 0 32 32" className="w-7 h-7 fill-current">
          <path d="M16 0C7.163 0 0 7.163 0 16c0 2.822.737 5.476 2.024 7.785L0 32l8.398-2.002A15.94 15.94 0 0016 32c8.837 0 16-7.163 16-16S24.837 0 16 0zm8.296 22.452c-.35.982-2.033 1.877-2.787 1.945-.708.065-1.374.33-4.633-1.042-3.912-1.649-6.38-5.674-6.57-5.936-.19-.263-1.543-2.055-1.543-3.913 0-1.858.973-2.77 1.32-3.142.35-.37.763-.463 1.017-.463.254 0 .508.002.73.014.234.012.548-.089.858.654.35.83 1.19 2.897 1.29 3.11.102.21.17.457.034.733-.136.275-.203.446-.406.686-.203.24-.427.536-.61.719-.203.203-.413.423-.178.83.234.41.042.656 1.97 2.828 1.358 1.525 2.48 1.99 2.83 2.215.35.225.555.19.762-.113.203-.305.877-1.016 1.112-1.367.234-.35.468-.292.791-.175.323.117 2.05.967 2.4 1.142.35.176.585.262.67.408.085.147.085.838-.265 1.82z"/>
        </svg>
      </a>
    </>
  )
}
