import PageHeader from '@/components/PageHeader'
import type { Metadata } from 'next'

export const metadata: Metadata = { title: 'Privacy Policy' }

const sections = [
  {
    title: 'Information We Collect',
    content: `When you visit Dreva, we collect information you provide directly — such as your name, email address, phone number, and shipping address when placing an order or registering an account. We also automatically collect certain data about your visit, including IP address, browser type, pages viewed, and time spent on the site. This is standard practice for all e-commerce websites and helps us improve your experience.`,
  },
  {
    title: 'How We Use Your Information',
    content: `We use the information we collect to process and fulfil your orders, communicate with you about your purchases, send transactional messages (order confirmations, shipping updates), and — with your consent — send our wellness newsletter and promotional offers. We do not use your data for any purpose beyond providing you a seamless shopping experience and keeping you informed about Dreva.`,
  },
  {
    title: 'Sharing Your Information',
    content: `We do not sell, rent, or trade your personal information to third parties. We share data only with trusted service providers necessary to operate our business — such as logistics partners for delivery, payment processors for secure transactions, and email service providers for communications. All such partners are contractually obligated to protect your data in accordance with applicable law.`,
  },
  {
    title: 'Data Security',
    content: `We implement industry-standard security measures to protect your personal information. All data transmissions are encrypted via SSL/TLS. Passwords are hashed and never stored in plain text. Our systems are regularly audited for vulnerabilities. However, no method of transmission over the internet is 100% secure; while we strive to protect your data, we cannot guarantee absolute security.`,
  },
  {
    title: 'Cookies',
    content: `We use cookies to enhance your browsing experience, remember your cart, and analyse site traffic. You can control cookie settings through your browser preferences. Disabling cookies may affect certain site functionality, such as persistent cart contents. We do not use third-party advertising cookies or tracking pixels.`,
  },
  {
    title: 'Your Rights',
    content: `You have the right to access, correct, or delete your personal data at any time. You may unsubscribe from marketing communications using the link in any email we send. To request data deletion or export, contact us at support@zkelite.store. We will respond within 30 days. Residents of certain jurisdictions may have additional rights under local data protection law.`,
  },
  {
    title: 'Children\'s Privacy',
    content: `Dreva's products and website are not directed at children under the age of 13. We do not knowingly collect personal information from children. If you believe we have inadvertently collected information from a child, please contact us immediately and we will delete it promptly.`,
  },
  {
    title: 'Changes to This Policy',
    content: `We may update this Privacy Policy from time to time to reflect changes in our practices or applicable law. We will notify registered users of material changes via email. The date of the most recent revision appears at the bottom of this page. Continued use of our site following any changes constitutes acceptance of the updated policy.`,
  },
]

export default function PrivacyPage() {
  return (
    <div>
      <PageHeader label="Legal" title="Privacy Policy" subtitle="Last updated: January 1, 2026" />
      <div className="max-w-3xl mx-auto px-4 sm:px-6 py-14">
        <p className="font-body font-light text-forest-600 text-base leading-relaxed mb-10 pb-8 border-b border-cream-200">
          ZK Elite Pvt. Ltd. (&quot;Dreva&quot;, &quot;we&quot;, &quot;us&quot;, or &quot;our&quot;) is committed to protecting and respecting your privacy. This policy explains how we collect, use, and safeguard your personal information when you visit our website or make a purchase.
        </p>

        <div className="space-y-10">
          {sections.map((section, i) => (
            <div key={section.title}>
              <h2 className="font-display text-2xl font-normal text-forest-900 mb-4">
                <span className="text-forest-300 font-body font-light text-lg mr-2">{i + 1}.</span>
                {section.title}
              </h2>
              <p className="font-body font-light text-forest-600 leading-[1.9] text-[1.02rem]">{section.content}</p>
            </div>
          ))}
        </div>

        <div className="mt-14 pt-8 border-t border-cream-200 bg-cream-50 rounded-sm p-6">
          <h3 className="font-display text-xl font-normal text-forest-900 mb-2">Questions about your privacy?</h3>
          <p className="font-body font-light text-forest-600 text-sm mb-4">
            Contact our Privacy Team at:
          </p>
          <p className="font-body text-sm text-forest-700">
            <strong className="font-medium">ZK Elite Pvt. Ltd.</strong><br />
            Raipur, Chhattisgarh, India — 492001<br />
            <a href="mailto:support@zkelite.store" className="text-forest-600 hover:text-forest-900 underline">support@zkelite.store</a>
          </p>
        </div>
      </div>
    </div>
  )
}
