'use client'
import { useState, useEffect, Suspense } from 'react'
import { useSearchParams } from 'next/navigation'
import { products, Product } from '@/lib/data'
import ProductCard from '@/components/ProductCard'
import PageHeader from '@/components/PageHeader'

const categories = [
  { id: 'all', label: 'All Products' },
  { id: 'superfood', label: '🌰 Superfoods' },
  { id: 'water', label: '💧 Alkaline Water' },
  { id: 'skincare', label: '✨ Skincare' },
]

const sortOptions = [
  { id: 'default', label: 'Featured' },
  { id: 'price-asc', label: 'Price: Low to High' },
  { id: 'price-desc', label: 'Price: High to Low' },
  { id: 'rating', label: 'Top Rated' },
]

function ShopContent() {
  const searchParams = useSearchParams()
  const catParam = searchParams.get('cat') || 'all'

  const [activeCategory, setActiveCategory] = useState(catParam)
  const [sort, setSort] = useState('default')
  const [search, setSearch] = useState('')

  useEffect(() => { setActiveCategory(catParam) }, [catParam])

  const filtered = products
    .filter(p => activeCategory === 'all' || p.category === activeCategory)
    .filter(p => !search || p.name.toLowerCase().includes(search.toLowerCase()) || p.tags.some(t => t.includes(search.toLowerCase())))
    .sort((a, b) => {
      if (sort === 'price-asc') return a.price - b.price
      if (sort === 'price-desc') return b.price - a.price
      if (sort === 'rating') return b.rating - a.rating
      return 0
    })

  return (
    <div>
      <PageHeader label="Our Store" title="All Products" subtitle="Premium wellness essentials, thoughtfully curated." />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-10">
        {/* Filters */}
        <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between mb-8">
          <div className="flex flex-wrap gap-2">
            {categories.map(cat => (
              <button key={cat.id} onClick={() => setActiveCategory(cat.id)}
                className={`px-4 py-2 text-xs font-body font-medium tracking-widest uppercase rounded-sm transition-all ${
                  activeCategory === cat.id
                    ? 'bg-forest-700 text-white'
                    : 'bg-cream-100 text-forest-700 hover:bg-forest-100'
                }`}>
                {cat.label}
              </button>
            ))}
          </div>
          <div className="flex gap-3">
            <input type="text" placeholder="Search products..." value={search}
              onChange={e => setSearch(e.target.value)}
              className="input-field !py-2 !px-3 text-sm w-48" />
            <select value={sort} onChange={e => setSort(e.target.value)}
              className="input-field !py-2 !px-3 text-sm w-auto">
              {sortOptions.map(o => <option key={o.id} value={o.id}>{o.label}</option>)}
            </select>
          </div>
        </div>

        {/* Count */}
        <p className="text-xs font-body text-forest-400 mb-6 tracking-wide uppercase">
          Showing {filtered.length} product{filtered.length !== 1 ? 's' : ''}
        </p>

        {/* Grid */}
        {filtered.length > 0 ? (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filtered.map(p => <ProductCard key={p.id} product={p} />)}
          </div>
        ) : (
          <div className="text-center py-20">
            <span className="text-5xl block mb-4">🌿</span>
            <p className="font-display text-2xl font-light text-forest-700">No products found</p>
            <p className="text-sm font-body text-forest-400 mt-2">Try a different search or category.</p>
          </div>
        )}
      </div>
    </div>
  )
}

export default function ShopPage() {
  return (
    <Suspense fallback={<div className="min-h-screen flex items-center justify-center"><span className="text-forest-400 font-body">Loading...</span></div>}>
      <ShopContent />
    </Suspense>
  )
}
