import Image from 'next/image'
import Link from 'next/link'
import { notFound } from 'next/navigation'
import { blogPosts } from '@/lib/data'
import type { Metadata } from 'next'

interface Props { params: { id: string } }

export async function generateStaticParams() {
  return blogPosts.map(p => ({ id: p.id }))
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const post = blogPosts.find(p => p.id === params.id)
  if (!post) return { title: 'Article Not Found' }
  return { title: post.title, description: post.excerpt }
}

const articleContent: Record<string, string[]> = {
  'makhana-superfood-guide': [
    "Makhana — also known as fox nuts, lotus seeds, or phool makhana — has been consumed in India for thousands of years as both food and medicine. Found across sacred ponds and wetlands, the Euryale ferox plant produces these small, puffed seeds that ancient Ayurvedic texts praised for their rejuvenating properties.",
    "Modern nutritional science has finally caught up. Makhana is classified as a low-glycemic, high-protein snack with a surprisingly rich micronutrient profile. Per 100g, it delivers roughly 9–10g of protein, 18g of fibre, and significant quantities of calcium, magnesium, phosphorus, and potassium.",
    "Unlike most snack foods, makhana contains flavonoids such as kaempferol, which research suggests may have anti-inflammatory and anti-ageing effects. The seeds are also remarkably low in saturated fat, making them one of the few truly guilt-free snacks that still satisfy.",
    "At Dreva, we source our makhana from Bihar and Chhattisgarh, where traditional cultivation methods have been refined over centuries. Our slow-roasting process preserves maximum nutrition while unlocking a deeper, nuttier flavour profile that you simply can't get from high-temperature industrial methods.",
    "Whether you're snacking on Himalayan Pink Salt, reaching for Peri Peri on movie night, or adding plain roasted makhana to your kheer, you're participating in a food tradition that spans millennia — and now has the clinical evidence to back it up.",
  ],
  'alkaline-water-science': [
    "The term 'alkaline water' gets thrown around a lot in wellness circles, often with more enthusiasm than evidence. So let's cut through the noise and explain what pH actually means for your body — and where alkaline water genuinely helps.",
    "pH is a measure of hydrogen ion concentration on a scale of 0 to 14. Pure water is neutral at pH 7. Alkaline water has a pH above 7 — typically 8 to 9.5. Your stomach operates at pH 1.5–3.5 (highly acidic, by design), while your blood maintains a tightly regulated pH of 7.35–7.45.",
    "Here's the nuance most brands skip: your body doesn't need alkaline water to 'neutralise acidity'. Your kidneys and respiratory system handle blood pH with extraordinary precision. However, the benefits of quality alkaline water are real — they just operate differently.",
    "Research suggests that alkaline water with added minerals (calcium, magnesium, potassium) may improve hydration at the cellular level. Smaller molecular clusters in ionised water may allow faster absorption across cell membranes. Athletes in particular have reported improved recovery and reduced acid reflux symptoms.",
    "Dreva Alkaline Water maintains a pH of 8.5–9.0 through a multi-stage mineralisation process, not chemical additives. The TDS (Total Dissolved Solids) of 150–200ppm reflects balanced mineral content — high enough to deliver electrolytes, low enough to taste clean.",
  ],
  'natural-skincare-routine': [
    "The skincare industry thrives on complexity. Twelve-step routines, ingredient acronyms, conflicting advice — it's overwhelming by design. But the most effective skincare routines are often the simplest ones, executed consistently.",
    "Step one: cleanse with intention. Choose a gentle, pH-balanced cleanser that removes the day without stripping your skin's natural barrier. Avoid sulphates if you have sensitive or dry skin. Cleanse once in the evening; in the morning, a simple water rinse is often enough.",
    "Step two: treat, don't overload. Pick one active ingredient and use it consistently for 8–12 weeks before judging results. Vitamin C in the morning for brightness and sun protection support. Niacinamide for pores and tone. Retinol (if your skin tolerates it) at night for cellular renewal.",
    "Step three: moisturise and protect. A well-formulated moisturiser supports your skin barrier — the thin protective layer that keeps moisture in and irritants out. In the morning, finish with SPF 30 or above. This single step prevents more damage than any combination of serums.",
    "What makes Dreva's skincare different is the integration of botanicals that have centuries of clinical use behind them — lotus seed extract, forest herb complexes, kokum butter — combined with evidence-backed actives like L-Ascorbic Acid and ceramides. Nature and science, working together.",
  ],
  'wellness-morning-rituals': [
    "The first 60 minutes of your day set the neurological tone for everything that follows. Small, consistent habits in the morning compound into profound changes in health, focus, and mood over months and years.",
    "Ritual one: hydrate before caffeine. Your body loses 400–600ml of water overnight through respiration and light perspiration. Before reaching for coffee, drink a large glass of Dreva Alkaline Water. This simple practice supports kidney function, metabolism, and morning cognition.",
    "Ritual two: sunlight exposure within 30 minutes of waking. Even on cloudy days, outdoor light signals the circadian system to suppress melatonin and boost cortisol appropriately. Five minutes on your balcony or by a window dramatically improves sleep quality that evening.",
    "Ritual three: a protein-first breakfast. Makhana, eggs, yogurt, or nuts — starting the day with protein stabilises blood sugar and reduces mid-morning cravings. A handful of Dreva Himalayan Salt Makhana with your morning chai delivers protein and minerals with zero guilt.",
    "Ritual four: single-tasking for 30 minutes. Check nothing. Write one intention for the day. Meditate, journal, or simply sit quietly. The quality of your attention in the first hour shapes every subsequent hour.",
  ],
  'dry-fruits-immunity': [
    "Immunity isn't built overnight — it's the cumulative result of months and years of nutritional choices, sleep, stress management, and activity. But few foods deliver as many immunity-supporting micronutrients per gram as premium dry fruits.",
    "Almonds are perhaps the most researched. A single 28g serving provides 37% of daily Vitamin E — a fat-soluble antioxidant that protects immune cells from oxidative damage. Almonds also contain prebiotic fibres that feed beneficial gut bacteria, which produce up to 70% of the body's immune response.",
    "Walnuts contain the highest omega-3 content of any tree nut. ALA (alpha-linolenic acid) is an essential fat that the body converts to EPA and DHA — both involved in regulating inflammatory responses. Chronic low-grade inflammation is now understood as the underlying mechanism in most preventable diseases.",
    "Cashews deliver zinc in meaningful amounts. Zinc is indispensable for the development and function of immune cells, particularly T-lymphocytes. Even mild zinc deficiency — common in India — is associated with impaired immunity, poor wound healing, and increased susceptibility to infection.",
    "Dreva's Premium Mixed Dry Fruits blend is designed with this nutritional synergy in mind — almonds, cashews, walnuts, and pistachios in ratios that maximise micronutrient breadth. No added salt, no coatings, no compromise. Just the cleanest nuts we can source.",
  ],
  'gut-health-essentials': [
    "The gut microbiome — the roughly 38 trillion microorganisms living in your digestive tract — has emerged as one of the most significant frontiers in modern medicine. Researchers now link gut health to immunity, mental health, metabolic function, skin conditions, and even cognitive performance.",
    "The foundation of a healthy microbiome is diversity. Different bacterial species thrive on different types of fibre, so dietary variety is the single most impactful lever you can pull. Aim to eat 30 different plant foods per week — this number, from the British Gut Project's research, correlates strongly with microbiome richness.",
    "Prebiotic fibre specifically feeds your beneficial bacteria. Makhana contains resistant starch and soluble fibre that pass undigested to the colon, where they ferment and produce short-chain fatty acids (SCFAs) like butyrate. Butyrate is the primary fuel for colonocytes (colon cells) and has anti-inflammatory properties.",
    "Hydration plays an underrated role. The gut requires water to maintain the mucus layer that protects intestinal walls and lubricates transit. Alkaline water's micro-clustered molecules may support faster cellular absorption, keeping gut tissue well-hydrated even during high fibre intake.",
    "Stress is perhaps the most overlooked gut disruptor. The gut-brain axis is a two-way highway — stress changes gut motility, permeability, and microbiome composition within 24 hours of onset. Morning rituals, adequate sleep, and adaptogenic herbs (ashwagandha, tulsi) all support both systems simultaneously.",
  ],
}

export default function BlogPostPage({ params }: Props) {
  const post = blogPosts.find(p => p.id === params.id)
  if (!post) notFound()

  const content = articleContent[post.id] || [post.excerpt]
  const relatedPosts = blogPosts.filter(p => p.id !== post.id && p.category === post.category).slice(0, 3)
  const otherPosts = relatedPosts.length < 3
    ? [...relatedPosts, ...blogPosts.filter(p => p.id !== post.id && p.category !== post.category)].slice(0, 3)
    : relatedPosts

  return (
    <div>
      {/* Hero */}
      <div className="relative h-[50vh] min-h-[380px] overflow-hidden">
        <Image src={post.image} alt={post.title} fill className="object-cover" priority />
        <div className="absolute inset-0 bg-gradient-to-t from-peat/80 via-peat/30 to-transparent" />
        <div className="absolute inset-0 flex flex-col justify-end px-4 sm:px-6 pb-10 max-w-4xl mx-auto w-full left-0 right-0">
          <div className="flex gap-3 mb-4">
            <span className="badge bg-forest-600 text-white">{post.category}</span>
            <span className="text-xs text-cream-200/70 font-body">{post.readTime} read</span>
          </div>
          <h1 className="font-display text-3xl sm:text-5xl font-light text-white leading-tight">{post.title}</h1>
        </div>
      </div>

      {/* Breadcrumb */}
      <div className="bg-cream-50 border-b border-cream-200 px-4 sm:px-6 py-3">
        <div className="max-w-4xl mx-auto flex items-center gap-2 text-xs font-body text-forest-400">
          <Link href="/" className="hover:text-forest-700">Home</Link>
          <span>/</span>
          <Link href="/blog" className="hover:text-forest-700">Blog</Link>
          <span>/</span>
          <span className="text-forest-700 truncate max-w-[200px]">{post.title}</span>
        </div>
      </div>

      {/* Article */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 py-14">
        <div className="grid lg:grid-cols-3 gap-14">
          {/* Body */}
          <article className="lg:col-span-2">
            {/* Author & meta */}
            <div className="flex items-center gap-4 mb-10 pb-8 border-b border-cream-200">
              <div className="w-12 h-12 rounded-full bg-forest-100 flex items-center justify-center text-xl flex-shrink-0">👤</div>
              <div>
                <p className="font-body font-medium text-forest-900 text-sm">{post.author}</p>
                <p className="text-xs text-forest-400 font-body">
                  {new Date(post.date).toLocaleDateString('en-IN', { day: 'numeric', month: 'long', year: 'numeric' })}
                  &nbsp;·&nbsp;{post.readTime} read
                </p>
              </div>
            </div>

            {/* Excerpt */}
            <p className="font-display text-xl font-light italic text-forest-700 leading-relaxed mb-8 border-l-2 border-forest-300 pl-5">
              {post.excerpt}
            </p>

            {/* Body paragraphs */}
            <div className="space-y-6">
              {content.map((para, i) => (
                <p key={i} className="font-body font-light text-forest-700 leading-[1.9] text-[1.05rem]">
                  {para}
                </p>
              ))}
            </div>

            {/* Tags */}
            <div className="mt-10 pt-8 border-t border-cream-200 flex flex-wrap gap-2">
              {[post.category, 'Dreva', 'Wellness', 'Natural Living'].map(tag => (
                <span key={tag} className="text-xs font-body font-light text-forest-500 bg-cream-100 px-3 py-1 rounded-full border border-cream-200">
                  #{tag}
                </span>
              ))}
            </div>
          </article>

          {/* Sidebar */}
          <aside className="lg:col-span-1">
            <div className="sticky top-28 space-y-8">
              {/* Shop CTA */}
              <div className="bg-peat text-white rounded-sm p-6">
                <p className="text-xs font-body font-medium tracking-[0.2em] uppercase text-sage mb-3">Shop Dreva</p>
                <h3 className="font-display text-xl font-light text-white mb-3">Ready to start?</h3>
                <p className="text-xs text-cream-200/60 font-body font-light mb-5 leading-relaxed">
                  Explore our premium wellness products — makhana, alkaline water, and natural skincare.
                </p>
                <Link href="/shop" className="btn-primary text-sm block text-center">
                  Shop Now
                </Link>
              </div>

              {/* Related */}
              {otherPosts.length > 0 && (
                <div>
                  <h3 className="font-body font-medium text-xs tracking-[0.2em] uppercase text-forest-400 mb-4">More Articles</h3>
                  <div className="space-y-4">
                    {otherPosts.map(related => (
                      <Link key={related.id} href={`/blog/${related.id}`}
                        className="flex gap-3 group">
                        <div className="relative w-16 h-16 flex-shrink-0 rounded-sm overflow-hidden">
                          <Image src={related.image} alt={related.title} fill className="object-cover group-hover:scale-105 transition-transform duration-300" />
                        </div>
                        <div>
                          <p className="text-sm font-body font-normal text-forest-800 leading-snug group-hover:text-forest-600 transition-colors line-clamp-2">{related.title}</p>
                          <p className="text-[10px] text-forest-400 font-body mt-1">{related.readTime} read</p>
                        </div>
                      </Link>
                    ))}
                  </div>
                </div>
              )}

              {/* Newsletter mini */}
              <div className="bg-forest-100 rounded-sm p-5">
                <p className="font-body font-medium text-xs tracking-widest uppercase text-forest-600 mb-2">Newsletter</p>
                <p className="font-body font-light text-forest-600 text-sm mb-4 leading-relaxed">
                  Get weekly wellness insights straight to your inbox.
                </p>
                <input type="email" placeholder="your@email.com" className="input-field text-sm mb-3" />
                <button className="btn-primary w-full text-center text-xs">Subscribe</button>
              </div>
            </div>
          </aside>
        </div>

        {/* Back to blog */}
        <div className="mt-14 pt-8 border-t border-cream-200">
          <Link href="/blog" className="inline-flex items-center gap-2 text-sm font-body font-medium text-forest-600 hover:text-forest-900 transition-colors">
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8} d="M7 16l-4-4m0 0l4-4m-4 4h18" />
            </svg>
            Back to Wellness Blog
          </Link>
        </div>
      </div>
    </div>
  )
}
