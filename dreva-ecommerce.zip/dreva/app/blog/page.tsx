import Image from 'next/image'
import Link from 'next/link'
import { blogPosts } from '@/lib/data'
import PageHeader from '@/components/PageHeader'

export const metadata = { title: 'Wellness Blog' }

export default function BlogPage() {
  const [featured, ...rest] = blogPosts

  return (
    <div>
      <PageHeader label="Dreva Journal" title="Wellness Insights" subtitle="Thoughtful articles on superfoods, hydration, skincare, and mindful living." />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-12">
        {/* Featured */}
        <Link href={`/blog/${featured.id}`} className="group grid md:grid-cols-2 gap-0 overflow-hidden rounded-sm border border-cream-200 product-card mb-12 block">
          <div className="relative h-64 md:h-auto min-h-[280px] overflow-hidden">
            <Image src={featured.image} alt={featured.title} fill className="object-cover group-hover:scale-105 transition-transform duration-700" />
          </div>
          <div className="p-8 bg-cream-50 flex flex-col justify-center">
            <div className="flex gap-3 mb-4">
              <span className="badge bg-forest-700 text-white">{featured.category}</span>
              <span className="text-xs text-forest-400 font-body">{featured.readTime} read</span>
            </div>
            <h2 className="font-display text-3xl font-light text-forest-900 mb-3 group-hover:text-forest-700 transition-colors">{featured.title}</h2>
            <p className="font-body font-light text-forest-600 text-sm leading-relaxed mb-5">{featured.excerpt}</p>
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-forest-200 flex items-center justify-center text-sm">👤</div>
              <div>
                <p className="text-xs font-body font-medium text-forest-800">{featured.author}</p>
                <p className="text-[10px] font-body text-forest-400">{new Date(featured.date).toLocaleDateString('en-IN', { day: 'numeric', month: 'long', year: 'numeric' })}</p>
              </div>
            </div>
          </div>
        </Link>

        {/* Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {rest.map(post => (
            <Link key={post.id} href={`/blog/${post.id}`} className="group block product-card rounded-sm overflow-hidden border border-cream-200 bg-white">
              <div className="relative h-48 overflow-hidden">
                <Image src={post.image} alt={post.title} fill className="object-cover group-hover:scale-105 transition-transform duration-600" />
              </div>
              <div className="p-5">
                <div className="flex items-center gap-3 mb-3">
                  <span className="badge bg-forest-100 text-forest-700">{post.category}</span>
                  <span className="text-[10px] font-body text-forest-400">{post.readTime} read</span>
                </div>
                <h3 className="font-display text-xl font-normal text-forest-900 mb-2 leading-snug group-hover:text-forest-700 transition-colors">{post.title}</h3>
                <p className="text-sm font-body font-light text-forest-500 line-clamp-2 mb-4">{post.excerpt}</p>
                <p className="text-xs font-body text-forest-400">{post.author} · {new Date(post.date).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' })}</p>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </div>
  )
}
