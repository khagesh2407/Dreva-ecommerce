'use client'
import { useCart } from '@/lib/cart-context'
import Image from 'next/image'
import Link from 'next/link'

export default function CartPage() {
  const { items, removeFromCart, updateQty, total, clearCart } = useCart()

  if (items.length === 0) {
    return (
      <div className="min-h-[70vh] flex flex-col items-center justify-center text-center px-4">
        <span className="text-6xl mb-6">🛒</span>
        <h1 className="font-display text-4xl font-light text-forest-900 mb-3">Your cart is empty</h1>
        <p className="font-body font-light text-forest-500 mb-8">Add some wellness to your cart.</p>
        <Link href="/shop" className="btn-primary">Browse Products</Link>
      </div>
    )
  }

  const delivery = total >= 499 ? 0 : 49

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-12">
      <div className="flex items-center justify-between mb-8">
        <h1 className="font-display text-4xl font-light text-forest-900">Your Cart</h1>
        <button onClick={clearCart} className="text-xs font-body text-forest-400 hover:text-red-500 transition-colors tracking-wide uppercase">
          Clear Cart
        </button>
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        {/* Items */}
        <div className="lg:col-span-2 space-y-4">
          {items.map(({ product, quantity }) => (
            <div key={product.id} className="flex gap-4 bg-white border border-cream-200 rounded-sm p-4">
              <div className="relative w-20 h-20 flex-shrink-0 rounded-sm overflow-hidden bg-cream-100">
                <Image src={product.image} alt={product.name} fill className="object-cover" />
              </div>
              <div className="flex-1 min-w-0">
                <h3 className="font-display text-lg font-normal text-forest-900 leading-tight mb-1 line-clamp-1">{product.name}</h3>
                <p className="text-xs font-body text-forest-400 capitalize mb-3">{product.category}</p>
                <div className="flex items-center justify-between">
                  <div className="flex items-center border border-cream-200 rounded-sm">
                    <button onClick={() => updateQty(product.id, quantity - 1)} className="w-8 h-8 flex items-center justify-center text-forest-600 hover:bg-cream-100 transition-colors">−</button>
                    <span className="w-8 text-center text-sm font-body font-medium">{quantity}</span>
                    <button onClick={() => updateQty(product.id, quantity + 1)} className="w-8 h-8 flex items-center justify-center text-forest-600 hover:bg-cream-100 transition-colors">+</button>
                  </div>
                  <span className="font-body font-semibold text-forest-900">₹{product.price * quantity}</span>
                </div>
              </div>
              <button onClick={() => removeFromCart(product.id)} className="flex-shrink-0 text-forest-300 hover:text-red-400 transition-colors p-1 self-start">
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>
          ))}
        </div>

        {/* Summary */}
        <div className="bg-cream-50 border border-cream-200 rounded-sm p-6 h-fit">
          <h2 className="font-display text-2xl font-normal text-forest-900 mb-5">Order Summary</h2>
          <div className="space-y-3 mb-5">
            <div className="flex justify-between text-sm font-body text-forest-700">
              <span>Subtotal</span><span>₹{total}</span>
            </div>
            <div className="flex justify-between text-sm font-body text-forest-700">
              <span>Delivery</span>
              <span className={delivery === 0 ? 'text-forest-600 font-medium' : ''}>
                {delivery === 0 ? 'FREE' : `₹${delivery}`}
              </span>
            </div>
            {delivery > 0 && (
              <p className="text-xs text-forest-400 font-body">Add ₹{499 - total} more for free delivery.</p>
            )}
          </div>
          <div className="border-t border-cream-200 pt-4 mb-6">
            <div className="flex justify-between font-body font-semibold text-forest-900">
              <span>Total</span><span>₹{total + delivery}</span>
            </div>
          </div>

          <button className="btn-primary w-full text-center mb-3">
            Proceed to Checkout
          </button>
          <a href={`https://wa.me/918224021324?text=Hi%20Dreva!%20I'd%20like%20to%20place%20an%20order%20for%20${encodeURIComponent(items.map(i => `${i.quantity}x ${i.product.name}`).join(', '))}%20— Total%3A%20%E2%82%B9${total + delivery}`}
            target="_blank" rel="noopener noreferrer"
            className="btn-outline w-full text-center block">
            💬 Order via WhatsApp
          </a>
        </div>
      </div>
    </div>
  )
}
