import Image from 'next/image'
import Link from 'next/link'
import PageHeader from '@/components/PageHeader'

export const metadata = { title: 'About Dreva' }

export default function AboutPage() {
  return (
    <div>
      <PageHeader
        label="Our Story"
        title="Rooted in Nature. Anchored in Wisdom."
        subtitle="A wellness brand born in Raipur, built with intention — for you and for the planet."
        dark
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-16">
        {/* Mission */}
        <div className="grid lg:grid-cols-2 gap-16 items-center mb-20">
          <div>
            <p className="text-xs font-body font-medium tracking-[0.3em] uppercase text-forest-500 mb-4">Our Mission</p>
            <h2 className="font-display text-4xl font-light text-forest-900 mb-6">
              Wellness begins with <em className="italic">purity</em>
            </h2>
            <p className="font-body font-light text-forest-600 text-lg leading-relaxed mb-5">
              At Dreva, we believe that the most powerful wellness rituals are rooted in the earth — in ancient grains, mineral-rich water, and botanical wisdom passed down through generations.
            </p>
            <p className="font-body font-light text-forest-600 leading-relaxed mb-5">
              Founded in Raipur, Chhattisgarh, we set out to create a brand that brings genuinely premium, thoughtfully crafted wellness products into every Indian home — without the compromises of mass production or the cynicism of trend-chasing.
            </p>
            <p className="font-body font-light text-forest-600 leading-relaxed">
              Every product we make is traceable, transparent, and tested. We are proud holders of FSSAI, Startup India, and MSME certifications — not just as credentials, but as commitments.
            </p>
          </div>
          <div className="relative h-96 rounded-sm overflow-hidden">
            <Image
              src="https://images.unsplash.com/photo-1490645935967-10de6ba17061?w=700&q=90"
              alt="Dreva wellness"
              fill
              className="object-cover"
            />
          </div>
        </div>

        {/* Values */}
        <div className="mb-20">
          <div className="text-center mb-12">
            <p className="text-xs font-body font-medium tracking-[0.3em] uppercase text-forest-500 mb-3">What We Stand For</p>
            <h2 className="font-display text-4xl font-light text-forest-900">Our Values</h2>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { icon: '🌿', title: 'Natural First', desc: 'Every formulation starts with nature. We use the cleanest ingredients we can source.' },
              { icon: '🔬', title: 'Science-Backed', desc: 'We apply rigorous research to ensure every product actually does what we promise.' },
              { icon: '🤝', title: 'Community Roots', desc: 'Sourced locally where possible, supporting farmers and artisans in Chhattisgarh and beyond.' },
              { icon: '🌍', title: 'Sustainable Future', desc: 'Minimal, eco-conscious packaging. No excess, no waste, no greenwashing.' },
            ].map(v => (
              <div key={v.title} className="text-center p-6 bg-cream-50 rounded-sm border border-cream-200">
                <span className="text-3xl block mb-4">{v.icon}</span>
                <h3 className="font-display text-xl font-normal text-forest-900 mb-3">{v.title}</h3>
                <p className="text-sm font-body font-light text-forest-600 leading-relaxed">{v.desc}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Team */}
        <div className="mb-20">
          <div className="text-center mb-12">
            <p className="text-xs font-body font-medium tracking-[0.3em] uppercase text-forest-500 mb-3">The People Behind Dreva</p>
            <h2 className="font-display text-4xl font-light text-forest-900">Our Team</h2>
          </div>
          <div className="grid sm:grid-cols-3 gap-6 max-w-3xl mx-auto">
            {[
              { name: 'Khagesh Soni', role: 'Founder & CEO', emoji: '🌿' },
              { name: 'Dr. Priya Sharma', role: 'Nutritionist & Advisor', emoji: '🔬' },
              { name: 'Rohan Mehta', role: 'Head of Product', emoji: '🧪' },
            ].map(m => (
              <div key={m.name} className="text-center p-6">
                <div className="w-20 h-20 bg-forest-100 rounded-full flex items-center justify-center text-3xl mx-auto mb-4">
                  {m.emoji}
                </div>
                <h3 className="font-display text-xl font-normal text-forest-900 mb-1">{m.name}</h3>
                <p className="text-xs font-body font-light text-forest-500 tracking-wide">{m.role}</p>
              </div>
            ))}
          </div>
        </div>

        {/* CTA */}
        <div className="bg-peat text-white rounded-sm p-12 text-center">
          <h2 className="font-display text-4xl font-light mb-4">Ready to start your wellness journey?</h2>
          <p className="font-body font-light text-cream-200/70 mb-8 text-lg">Browse our full collection of nature-rooted products.</p>
          <Link href="/shop" className="btn-primary">Shop All Products</Link>
        </div>
      </div>
    </div>
  )
}
