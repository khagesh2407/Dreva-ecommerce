import PageHeader from '@/components/PageHeader'
import type { Metadata } from 'next'

export const metadata: Metadata = { title: 'Terms of Service' }

const sections = [
  {
    title: 'Acceptance of Terms',
    content: `By accessing or using the Dreva website (dreva-ecommerce.vercel.app or any associated domain operated by ZK Elite Pvt. Ltd.), you agree to be bound by these Terms of Service and our Privacy Policy. If you do not agree to these terms, please do not use our site. These terms apply to all visitors, users, and customers.`,
  },
  {
    title: 'Products and Pricing',
    content: `All products listed on our website are subject to availability. We reserve the right to discontinue any product at any time without notice. Prices are displayed in Indian Rupees (INR) and include applicable taxes unless stated otherwise. We reserve the right to change prices at any time. In the event of a pricing error, we will notify you before processing your order and give you the option to proceed at the correct price or cancel.`,
  },
  {
    title: 'Orders and Payment',
    content: `By placing an order, you represent that you are legally capable of entering into a binding contract and are at least 18 years of age. We accept payment via UPI, credit/debit cards, net banking, and WhatsApp-based order confirmations. Orders are confirmed only upon receipt of successful payment. We reserve the right to refuse or cancel any order for reasons including but not limited to product unavailability, errors in product information, or suspected fraudulent activity.`,
  },
  {
    title: 'Shipping and Delivery',
    content: `We ship pan-India. Delivery timelines are estimates and may vary due to location, courier delays, or unforeseen circumstances. Free delivery is available on orders above ₹499. We are not liable for delays caused by third-party logistics providers, natural events, or incorrect shipping addresses provided by the customer. Once an order is dispatched, tracking information will be shared via email or WhatsApp.`,
  },
  {
    title: 'Returns and Refunds',
    content: `We want you to be completely satisfied with your Dreva purchase. If you receive a damaged, defective, or incorrect product, contact us within 48 hours of delivery with photographic evidence at support@zkelite.store or via WhatsApp. We will arrange a replacement or full refund at our discretion. Opened food products (makhana, dry fruits) cannot be returned for hygiene reasons unless damaged. Skincare and water products may be returned unopened within 7 days.`,
  },
  {
    title: 'Product Information',
    content: `We strive for accuracy in all product descriptions, nutritional information, and ingredient lists. However, minor variations may occur. All food products comply with FSSAI regulations. Allergen information is listed on product packaging — please read labels carefully before consumption. Results from skincare products may vary individually. Our products are not intended to diagnose, treat, cure, or prevent any medical condition. Consult a healthcare professional before use if you have a medical condition or are pregnant.`,
  },
  {
    title: 'Intellectual Property',
    content: `All content on this website — including text, images, logos, product designs, and the Dreva brand identity — is the exclusive property of ZK Elite Pvt. Ltd. and is protected by copyright and trademark law. You may not reproduce, distribute, or commercially exploit any content without prior written permission. Unauthorised use of our brand assets or content may result in legal action.`,
  },
  {
    title: 'Limitation of Liability',
    content: `To the fullest extent permitted by law, ZK Elite Pvt. Ltd. shall not be liable for any indirect, incidental, special, or consequential damages arising from your use of our products or website. Our liability in connection with any purchase shall not exceed the amount you paid for the relevant product. This limitation applies regardless of the legal theory under which liability is claimed.`,
  },
  {
    title: 'Governing Law',
    content: `These Terms of Service are governed by and construed in accordance with the laws of India. Any disputes arising under these terms shall be subject to the exclusive jurisdiction of the courts in Raipur, Chhattisgarh, India.`,
  },
]

export default function TermsPage() {
  return (
    <div>
      <PageHeader label="Legal" title="Terms of Service" subtitle="Last updated: January 1, 2026" />
      <div className="max-w-3xl mx-auto px-4 sm:px-6 py-14">
        <p className="font-body font-light text-forest-600 text-base leading-relaxed mb-10 pb-8 border-b border-cream-200">
          Please read these Terms of Service carefully before using the Dreva website or placing an order. These terms constitute a legally binding agreement between you and ZK Elite Pvt. Ltd.
        </p>

        <div className="space-y-10">
          {sections.map((section, i) => (
            <div key={section.title}>
              <h2 className="font-display text-2xl font-normal text-forest-900 mb-4">
                <span className="text-forest-300 font-body font-light text-lg mr-2">{i + 1}.</span>
                {section.title}
              </h2>
              <p className="font-body font-light text-forest-600 leading-[1.9] text-[1.02rem]">{section.content}</p>
            </div>
          ))}
        </div>

        <div className="mt-14 pt-8 border-t border-cream-200 bg-cream-50 rounded-sm p-6">
          <h3 className="font-display text-xl font-normal text-forest-900 mb-2">Questions about these terms?</h3>
          <p className="font-body font-light text-forest-600 text-sm mb-4">We&apos;re happy to clarify anything. Get in touch:</p>
          <p className="font-body text-sm text-forest-700">
            <strong className="font-medium">ZK Elite Pvt. Ltd.</strong><br />
            Raipur, Chhattisgarh, India — 492001<br />
            <a href="mailto:support@zkelite.store" className="text-forest-600 hover:text-forest-900 underline">support@zkelite.store</a>
          </p>
        </div>
      </div>
    </div>
  )
}
