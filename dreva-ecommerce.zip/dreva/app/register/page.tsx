'use client'
import { useState } from 'react'
import Link from 'next/link'

export default function RegisterPage() {
  const [form, setForm] = useState({ name: '', email: '', phone: '', password: '' })

  return (
    <div className="min-h-[80vh] flex items-center justify-center bg-cream-50 px-4 py-12">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <span className="text-4xl block mb-3">🌿</span>
          <h1 className="font-display text-4xl font-light text-forest-900 mb-2">Join Dreva</h1>
          <p className="font-body font-light text-forest-500 text-sm">Create your wellness account</p>
        </div>

        <div className="bg-white border border-cream-200 rounded-sm p-8">
          <form className="space-y-5" onSubmit={e => e.preventDefault()}>
            <div>
              <label className="block text-xs font-body font-medium tracking-widest uppercase text-forest-600 mb-2">Full Name</label>
              <input type="text" required placeholder="Your name" value={form.name}
                onChange={e => setForm({ ...form, name: e.target.value })}
                className="input-field" />
            </div>
            <div>
              <label className="block text-xs font-body font-medium tracking-widests uppercase text-forest-600 mb-2">Email</label>
              <input type="email" required placeholder="your@email.com" value={form.email}
                onChange={e => setForm({ ...form, email: e.target.value })}
                className="input-field" />
            </div>
            <div>
              <label className="block text-xs font-body font-medium tracking-widest uppercase text-forest-600 mb-2">Phone</label>
              <input type="tel" placeholder="+91 98765 43210" value={form.phone}
                onChange={e => setForm({ ...form, phone: e.target.value })}
                className="input-field" />
            </div>
            <div>
              <label className="block text-xs font-body font-medium tracking-widest uppercase text-forest-600 mb-2">Password</label>
              <input type="password" required placeholder="Create a password" value={form.password}
                onChange={e => setForm({ ...form, password: e.target.value })}
                className="input-field" />
            </div>
            <button type="submit" className="btn-primary w-full text-center">Create Account</button>
          </form>

          <div className="mt-6 pt-6 border-t border-cream-100 text-center">
            <p className="text-sm font-body font-light text-forest-500">
              Already have an account?{' '}
              <Link href="/login" className="text-forest-700 font-medium hover:text-forest-900 transition-colors">
                Sign in →
              </Link>
            </p>
          </div>
        </div>

        <p className="text-xs text-center text-forest-400 font-body mt-4">
          By creating an account, you agree to our Terms of Service and Privacy Policy.
        </p>
      </div>
    </div>
  )
}
