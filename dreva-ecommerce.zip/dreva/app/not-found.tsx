import Link from 'next/link'

export default function NotFound() {
  return (
    <div className="min-h-[80vh] flex flex-col items-center justify-center text-center px-4">
      <span className="text-6xl mb-6">🌿</span>
      <p className="font-body text-xs font-medium tracking-[0.3em] uppercase text-forest-400 mb-2">404</p>
      <h1 className="font-display text-5xl font-light text-forest-900 mb-4">Page not found</h1>
      <p className="font-body font-light text-forest-500 mb-8 max-w-sm">
        This page has wandered off into the forest. Let&apos;s guide you back.
      </p>
      <div className="flex gap-4">
        <Link href="/" className="btn-primary">Go Home</Link>
        <Link href="/shop" className="btn-outline">Browse Shop</Link>
      </div>
    </div>
  )
}
