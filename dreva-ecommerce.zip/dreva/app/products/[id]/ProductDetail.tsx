'use client'
import { useState } from 'react'
import Image from 'next/image'
import Link from 'next/link'
import { notFound } from 'next/navigation'
import { getProductById, products } from '@/lib/data'
import { useCart } from '@/lib/cart-context'
import ProductCard from '@/components/ProductCard'

export default function ProductDetail({ id }: { id: string }) {
  const product = getProductById(id)
  if (!product) notFound()

  const { addToCart } = useCart()
  const [qty, setQty] = useState(1)
  const [added, setAdded] = useState(false)

  const related = products.filter(p => p.category === product.category && p.id !== product.id).slice(0, 4)
  const stars = Array.from({ length: 5 }, (_, i) => i < Math.round(product.rating))

  const handleAdd = () => {
    addToCart(product, qty)
    setAdded(true)
    setTimeout(() => setAdded(false), 2000)
  }

  return (
    <div>
      {/* Breadcrumb */}
      <div className="bg-cream-50 border-b border-cream-200 px-4 sm:px-6 py-3">
        <div className="max-w-7xl mx-auto flex items-center gap-2 text-xs font-body text-forest-400">
          <Link href="/" className="hover:text-forest-700">Home</Link>
          <span>/</span>
          <Link href="/shop" className="hover:text-forest-700">Shop</Link>
          <span>/</span>
          <span className="text-forest-700 capitalize">{product.category}</span>
          <span>/</span>
          <span className="text-forest-900 font-medium">{product.name}</span>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-12">
        <div className="grid lg:grid-cols-2 gap-12 items-start">
          {/* Image */}
          <div className="sticky top-24">
            <div className="relative h-[480px] bg-cream-100 rounded-sm overflow-hidden">
              <Image src={product.image} alt={product.name} fill className="object-cover" priority />
              {product.badge && (
                <span className="absolute top-5 left-5 badge bg-forest-700 text-white text-sm">{product.badge}</span>
              )}
            </div>
          </div>

          {/* Details */}
          <div>
            <p className="text-xs font-body font-medium tracking-[0.25em] uppercase text-forest-400 mb-3 capitalize">
              {product.category}
            </p>
            <h1 className="font-display text-4xl sm:text-5xl font-light text-forest-900 mb-4 leading-tight">
              {product.name}
            </h1>

            {/* Rating */}
            <div className="flex items-center gap-3 mb-5">
              <div className="flex stars text-lg">
                {stars.map((filled, i) => (
                  <span key={i} className={filled ? 'text-cream-500' : 'text-cream-300'}>★</span>
                ))}
              </div>
              <span className="text-sm font-body text-forest-500">{product.rating} ({product.reviews} reviews)</span>
            </div>

            {/* Price */}
            <div className="flex items-baseline gap-3 mb-6">
              <span className="font-body text-3xl font-semibold text-forest-900">₹{product.price}</span>
              {product.originalPrice && (
                <>
                  <span className="font-body text-xl text-forest-400 line-through">₹{product.originalPrice}</span>
                  <span className="badge bg-cream-200 text-bark-700 text-sm">
                    Save ₹{product.originalPrice - product.price}
                  </span>
                </>
              )}
            </div>

            <p className="font-body font-light text-forest-600 text-base leading-relaxed mb-7">
              {product.description}
            </p>

            {/* Benefits */}
            <div className="mb-7">
              <h3 className="font-body font-medium text-xs tracking-[0.2em] uppercase text-forest-500 mb-3">Key Benefits</h3>
              <ul className="space-y-2">
                {product.benefits.map(b => (
                  <li key={b} className="flex items-start gap-2 text-sm font-body font-light text-forest-700">
                    <span className="text-forest-500 mt-0.5">🌿</span> {b}
                  </li>
                ))}
              </ul>
            </div>

            {/* Quantity + Add to cart */}
            <div className="flex items-center gap-4 mb-5">
              <div className="flex items-center border border-cream-300 rounded-sm">
                <button onClick={() => setQty(Math.max(1, qty - 1))}
                  className="w-10 h-10 flex items-center justify-center text-forest-700 hover:bg-cream-100 transition-colors font-body text-lg">
                  −
                </button>
                <span className="w-10 text-center font-body font-medium text-forest-900">{qty}</span>
                <button onClick={() => setQty(qty + 1)}
                  className="w-10 h-10 flex items-center justify-center text-forest-700 hover:bg-cream-100 transition-colors font-body text-lg">
                  +
                </button>
              </div>
              <button onClick={handleAdd}
                className={`btn-primary flex-1 text-center transition-all ${added ? '!bg-forest-600' : ''}`}>
                {added ? '✓ Added to Cart' : 'Add to Cart'}
              </button>
            </div>

            <a href="https://wa.me/918224021324?text=Hi!%20I%27m%20interested%20in%20"
              target="_blank" rel="noopener noreferrer"
              className="btn-outline w-full text-center block">
              💬 Order via WhatsApp
            </a>

            {/* Specs */}
            <div className="mt-8 border border-cream-200 rounded-sm overflow-hidden">
              <h3 className="font-body font-medium text-xs tracking-[0.2em] uppercase text-forest-500 px-4 py-3 bg-cream-50 border-b border-cream-200">
                Specifications
              </h3>
              {product.specs.map((s, i) => (
                <div key={s.label} className={`flex justify-between px-4 py-3 text-sm font-body ${i % 2 === 0 ? 'bg-white' : 'bg-cream-50'}`}>
                  <span className="font-medium text-forest-600">{s.label}</span>
                  <span className="font-light text-forest-800">{s.value}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Related Products */}
        {related.length > 0 && (
          <div className="mt-20">
            <h2 className="font-display text-3xl font-light text-forest-900 mb-8">You May Also Like</h2>
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {related.map(p => <ProductCard key={p.id} product={p} />)}
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
