import type { Metadata } from 'next'
import './globals.css'
import Navbar from '@/components/Navbar'
import Footer from '@/components/Footer'
import { CartProvider } from '@/lib/cart-context'

export const metadata: Metadata = {
  title: { default: 'Dreva — Rooted in Nature. Anchored in Wisdom.', template: '%s | Dreva' },
  description: 'Premium wellness products — superfood makhana, alkaline water, and natural skincare. Thoughtfully crafted by ZK Elite Pvt. Ltd., Raipur.',
  keywords: ['makhana', 'alkaline water', 'natural skincare', 'wellness', 'superfood', 'Dreva'],
  openGraph: {
    title: 'Dreva — Premium Wellness Store',
    description: 'Rooted in Nature. Anchored in Wisdom.',
    siteName: 'Dreva',
    locale: 'en_IN',
    type: 'website',
  },
  icons: { icon: '/favicon.svg' },
}

export const viewport = {
  themeColor: '#2d652b',
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link rel="icon" type="image/svg+xml" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32'><text y='28' font-size='28'>🌿</text></svg>" />
      </head>
      <body>
        <CartProvider>
          <Navbar />
          <main>{children}</main>
          <Footer />
        </CartProvider>
      </body>
    </html>
  )
}
