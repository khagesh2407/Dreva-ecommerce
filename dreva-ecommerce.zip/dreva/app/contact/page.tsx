import PageHeader from '@/components/PageHeader'
import ContactForm from '@/components/ContactForm'

export const metadata = { title: 'Contact Us' }

export default function ContactPage() {
  return (
    <div>
      <PageHeader label="Reach Out" title="Contact Us" subtitle="Questions, feedback, or just want to say hello? We'd love to hear from you." />

      <div className="max-w-6xl mx-auto px-4 sm:px-6 py-16">
        <div className="grid lg:grid-cols-2 gap-14">
          {/* Form */}
          <div>
            <h2 className="font-display text-3xl font-light text-forest-900 mb-8">Send a Message</h2>
            <ContactForm />
          </div>

          {/* Info */}
          <div>
            <h2 className="font-display text-3xl font-light text-forest-900 mb-8">Other Ways to Reach Us</h2>
            <div className="space-y-6">
              {[
                { icon: '📍', title: 'Address', lines: ['ZK Elite Pvt. Ltd.', 'Raipur, Chhattisgarh', 'India — 492001'] },
                { icon: '✉️', title: 'Email', lines: ['support@zkelite.store'] },
                { icon: '📞', title: 'WhatsApp', lines: ['+91 82240 21324', 'Mon–Sat, 9am–7pm IST'] },
              ].map(info => (
                <div key={info.title} className="flex gap-4 p-5 bg-cream-50 border border-cream-200 rounded-sm">
                  <span className="text-2xl">{info.icon}</span>
                  <div>
                    <h3 className="font-body font-medium text-xs tracking-widest uppercase text-forest-500 mb-1">{info.title}</h3>
                    {info.lines.map(l => (
                      <p key={l} className="font-body font-light text-forest-700 text-sm">{l}</p>
                    ))}
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-8 p-6 bg-forest-800 text-white rounded-sm">
              <p className="font-body font-light text-cream-200/80 text-sm mb-4">
                For the fastest response, reach us on WhatsApp. We typically reply within 30 minutes during business hours.
              </p>
              <a href="https://wa.me/918224021324?text=Hi%20Dreva!%20I%27d%20like%20to%20know%20more."
                target="_blank" rel="noopener noreferrer"
                className="btn-primary !bg-green-600 hover:!bg-green-700 inline-flex items-center gap-2">
                <svg viewBox="0 0 32 32" className="w-4 h-4 fill-current">
                  <path d="M16 0C7.163 0 0 7.163 0 16c0 2.822.737 5.476 2.024 7.785L0 32l8.398-2.002A15.94 15.94 0 0016 32c8.837 0 16-7.163 16-16S24.837 0 16 0z"/>
                </svg>
                Chat on WhatsApp
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
