# 🌿 Dreva — Premium Wellness D2C E-Commerce

> Rooted in Nature. Anchored in Wisdom.

A modern, production-ready e-commerce platform for premium wellness products built with **Next.js 14**, **TypeScript**, and **Tailwind CSS**.

## 🚀 Quick Deploy to Vercel

[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new)

1. Push this repo to GitHub
2. Import to Vercel — it auto-detects Next.js
3. Deploy — done in ~2 minutes!

## 🏃 Local Development

```bash
npm install
npm run dev
# Open http://localhost:3000
```

## 🏗️ Build for Production

```bash
npm run build
npm start
```

## 🌿 Product Categories

| Category | Products |
|----------|----------|
| **Dreva Superfood** | Makhana (3 flavours), Premium Dry Fruits |
| **Dreva Alkaline Water** | 500ml, 1L, 12-Pack |
| **Dreva Skincare** | Vitamin C Serum, Moisture Cream, Face Mask, Lip Balm, Face Mist |

## ✨ Features

- ✅ Responsive, mobile-first design
- ✅ Product catalog with 12+ SKUs
- ✅ Full product detail pages with specs
- ✅ Shopping cart with persistent state
- ✅ WhatsApp order integration
- ✅ Blog / Wellness Journal (6 articles)
- ✅ Contact form
- ✅ Newsletter signup
- ✅ Login & Register pages
- ✅ SEO optimised (metadata, OG tags)
- ✅ TypeScript throughout
- ✅ Zero external API dependencies

## 🛠️ Tech Stack

- **Framework**: Next.js 14 (App Router)
- **Language**: TypeScript
- **Styling**: Tailwind CSS + Custom CSS
- **Fonts**: Cormorant Garamond + DM Sans
- **Deployment**: Vercel

## 📂 Project Structure

```
dreva/
├── app/                    # Next.js App Router pages
│   ├── page.tsx            # Home
│   ├── shop/               # Product catalog
│   ├── products/[id]/      # Product detail
│   ├── blog/               # Wellness blog
│   ├── about/              # About Dreva
│   ├── contact/            # Contact
│   ├── cart/               # Shopping cart
│   ├── login/              # Login
│   └── register/           # Register
├── components/             # Reusable components
│   ├── Navbar.tsx
│   ├── Footer.tsx
│   ├── HeroSection.tsx
│   ├── Categories.tsx
│   ├── ProductCard.tsx
│   ├── FeaturedProducts.tsx
│   ├── WhyChooseDreva.tsx
│   ├── Newsletter.tsx
│   ├── PageHeader.tsx
│   └── ContactForm.tsx
├── lib/
│   ├── data.ts             # Products & blog data
│   └── cart-context.tsx    # Cart state management
├── vercel.json
└── next.config.js
```

## 📞 Contact

- **Email**: support@zkelite.store
- **WhatsApp**: +91 82240 21324
- **Location**: Raipur, Chhattisgarh, India

---

© 2026 ZK Elite Pvt. Ltd. All Rights Reserved.
