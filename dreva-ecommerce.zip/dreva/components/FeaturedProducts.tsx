import Link from 'next/link'
import { getFeaturedProducts } from '@/lib/data'
import ProductCard from './ProductCard'

export default function FeaturedProducts() {
  const featured = getFeaturedProducts()

  return (
    <section className="section bg-cream-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="flex items-end justify-between mb-12">
          <div>
            <p className="text-xs font-body font-medium tracking-[0.3em] uppercase text-forest-500 mb-3">
              Hand-picked for you
            </p>
            <h2 className="font-display text-4xl sm:text-5xl font-light text-forest-900">
              Featured Products
            </h2>
          </div>
          <Link href="/shop" className="hidden sm:inline-flex items-center gap-2 text-sm font-body font-medium text-forest-600 hover:text-forest-900 transition-colors tracking-wide">
            View All
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8} d="M17 8l4 4m0 0l-4 4m4-4H3" />
            </svg>
          </Link>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {featured.map(product => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>

        <div className="text-center mt-10 sm:hidden">
          <Link href="/shop" className="btn-outline">View All Products</Link>
        </div>
      </div>
    </section>
  )
}
