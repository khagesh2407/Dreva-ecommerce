'use client'
import Link from 'next/link'
import { useState, useEffect } from 'react'
import { useCart } from '@/lib/cart-context'

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false)
  const [menuOpen, setMenuOpen] = useState(false)
  const { count } = useCart()

  useEffect(() => {
    const handler = () => setScrolled(window.scrollY > 20)
    window.addEventListener('scroll', handler)
    return () => window.removeEventListener('scroll', handler)
  }, [])

  const navLinks = [
    { href: '/shop', label: 'Shop' },
    { href: '/shop?cat=superfood', label: 'Superfoods' },
    { href: '/shop?cat=water', label: 'Alkaline Water' },
    { href: '/shop?cat=skincare', label: 'Skincare' },
    { href: '/blog', label: 'Wellness' },
    { href: '/about', label: 'About' },
  ]

  return (
    <>
      <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled ? 'bg-white/95 backdrop-blur-md shadow-sm py-3' : 'bg-cream-50/80 backdrop-blur-sm py-5'
      }`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 flex items-center justify-between">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2 group">
            <span className="text-2xl group-hover:animate-leaf-sway inline-block transition-transform">🌿</span>
            <div>
              <span className="font-display text-2xl font-semibold text-forest-800 tracking-wide leading-none">Dreva</span>
              <span className="block text-[9px] text-bark-500 tracking-[0.2em] uppercase font-body font-normal leading-none mt-0.5">by ZK Elite</span>
            </div>
          </Link>

          {/* Desktop nav */}
          <div className="hidden lg:flex items-center gap-7">
            {navLinks.map(link => (
              <Link key={link.href} href={link.href}
                className="organic-underline text-sm text-forest-700 hover:text-forest-900 font-body font-normal tracking-wide transition-colors">
                {link.label}
              </Link>
            ))}
          </div>

          {/* Actions */}
          <div className="flex items-center gap-4">
            <Link href="/login" className="hidden sm:block text-sm text-forest-700 hover:text-forest-900 transition-colors font-body">
              Login
            </Link>
            <Link href="/cart" className="relative p-2 hover:bg-forest-100 rounded-full transition-colors">
              <svg className="w-5 h-5 text-forest-800" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8} d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"/>
              </svg>
              {count > 0 && (
                <span className="absolute -top-1 -right-1 w-5 h-5 bg-forest-600 text-white text-[10px] font-semibold rounded-full flex items-center justify-center">
                  {count}
                </span>
              )}
            </Link>
            {/* Mobile menu toggle */}
            <button className="lg:hidden p-2 hover:bg-forest-100 rounded-full transition-colors"
              onClick={() => setMenuOpen(!menuOpen)}>
              <svg className="w-5 h-5 text-forest-800" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                {menuOpen
                  ? <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8} d="M6 18L18 6M6 6l12 12"/>
                  : <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8} d="M4 6h16M4 12h16M4 18h16"/>}
              </svg>
            </button>
          </div>
        </div>

        {/* Mobile menu */}
        {menuOpen && (
          <div className="lg:hidden bg-white border-t border-cream-200 px-4 py-4 space-y-3">
            {navLinks.map(link => (
              <Link key={link.href} href={link.href}
                onClick={() => setMenuOpen(false)}
                className="block text-sm text-forest-700 py-2 border-b border-cream-100 font-body">
                {link.label}
              </Link>
            ))}
            <Link href="/login" onClick={() => setMenuOpen(false)}
              className="block text-sm text-forest-700 py-2 font-body">Login / Register</Link>
          </div>
        )}
      </nav>
      {/* Spacer */}
      <div className="h-16 lg:h-20" />
    </>
  )
}
