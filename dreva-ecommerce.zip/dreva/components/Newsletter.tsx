'use client'
import { useState } from 'react'

export default function Newsletter() {
  const [email, setEmail] = useState('')
  const [submitted, setSubmitted] = useState(false)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (email) { setSubmitted(true) }
  }

  return (
    <section className="section bg-cream-100">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 text-center">
        <span className="text-4xl block mb-6">🌿</span>
        <h2 className="font-display text-4xl sm:text-5xl font-light text-forest-900 mb-4">
          Join the Wellness Circle
        </h2>
        <p className="font-body font-light text-forest-600 mb-8 text-lg leading-relaxed">
          Get seasonal wellness tips, exclusive product launches, and members-only discounts — straight to your inbox.
        </p>

        {submitted ? (
          <div className="bg-forest-100 border border-forest-300 rounded-sm px-8 py-5 inline-block">
            <p className="font-body font-medium text-forest-800">🎉 Welcome to the Dreva family!</p>
            <p className="text-sm text-forest-600 font-body font-light mt-1">Check your inbox for a special welcome offer.</p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-3 max-w-lg mx-auto">
            <input
              type="email"
              placeholder="your@email.com"
              value={email}
              onChange={e => setEmail(e.target.value)}
              required
              className="input-field flex-1"
            />
            <button type="submit" className="btn-primary whitespace-nowrap">
              Subscribe
            </button>
          </form>
        )}

        <p className="text-xs text-forest-400 font-body mt-4">
          No spam, ever. Unsubscribe anytime. We respect your inbox.
        </p>
      </div>
    </section>
  )
}
