import Link from 'next/link'
import Image from 'next/image'

export default function HeroSection() {
  return (
    <section className="relative overflow-hidden bg-cream-100 min-h-[88vh] flex items-center">
      {/* Background texture */}
      <div className="absolute inset-0 opacity-[0.03]"
        style={{ backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%232d652b' fill-opacity='1'%3E%3Ccircle cx='30' cy='30' r='1.5'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")` }}
      />

      {/* Organic blob decorations */}
      <div className="absolute -top-20 -right-20 w-96 h-96 rounded-full opacity-10"
        style={{ background: 'radial-gradient(circle, #3d7f3a 0%, transparent 70%)' }} />
      <div className="absolute bottom-0 -left-20 w-64 h-64 opacity-8"
        style={{ background: 'radial-gradient(circle, #7b9e7a 0%, transparent 70%)', borderRadius: '60% 40% 30% 70% / 60% 30% 70% 40%' }} />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 w-full py-20">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Text */}
          <div>
            <div className="inline-flex items-center gap-2 bg-forest-100 text-forest-700 px-3 py-1.5 rounded-full text-xs font-body font-medium tracking-widest uppercase mb-8 animate-fade-up stagger-1">
              <span className="w-1.5 h-1.5 bg-forest-600 rounded-full animate-pulse" />
              New Season Collection
            </div>

            <h1 className="font-display text-5xl sm:text-6xl lg:text-7xl font-light text-forest-900 leading-[1.05] tracking-tight mb-6 animate-fade-up stagger-2">
              Rooted in{' '}
              <em className="italic text-moss font-light relative">
                Nature
                <svg className="absolute -bottom-1 left-0 w-full" height="4" viewBox="0 0 100 4" preserveAspectRatio="none">
                  <path d="M0 2 Q25 0 50 2 Q75 4 100 2" stroke="#7b9e7a" strokeWidth="1.5" fill="none" />
                </svg>
              </em>
              <br />Anchored in Wisdom
            </h1>

            <p className="font-body text-lg text-forest-700/80 font-light leading-relaxed max-w-lg mb-8 animate-fade-up stagger-3">
              Premium wellness products thoughtfully crafted for every home — 
              from superfood makhana to alkaline water and natural skincare.
            </p>

            <div className="flex flex-wrap gap-4 mb-10 animate-fade-up stagger-4">
              <Link href="/shop" className="btn-primary">
                Shop Now
              </Link>
              <Link href="/about" className="btn-outline">
                Our Story
              </Link>
            </div>

            {/* Trust badges */}
            <div className="flex flex-wrap gap-5 animate-fade-up stagger-5">
              {[
                { icon: '🏛️', text: 'FSSAI Certified' },
                { icon: '🚀', text: 'Startup India' },
                { icon: '🏆', text: 'MSME Registered' },
              ].map(b => (
                <div key={b.text} className="flex items-center gap-2">
                  <span>{b.icon}</span>
                  <span className="text-xs text-forest-600 font-body font-medium tracking-wide">{b.text}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Hero visual */}
          <div className="relative lg:block animate-fade-up stagger-3">
            <div className="relative h-[520px] animate-float" style={{ animationDuration: '7s' }}>
              {/* Main featured image */}
              <div className="absolute inset-0 rounded-[40%_60%_60%_40%_/_40%_40%_60%_60%] overflow-hidden shadow-2xl">
                <Image
                  src="https://images.unsplash.com/photo-1604977042946-1eecc30f269e?w=700&q=90"
                  alt="Premium Makhana by Dreva"
                  fill
                  className="object-cover"
                  priority
                />
                <div className="absolute inset-0 bg-gradient-to-t from-forest-900/20 to-transparent" />
              </div>

              {/* Floating card 1 */}
              <div className="absolute -left-8 top-12 bg-white rounded-2xl shadow-lg px-4 py-3 flex items-center gap-3 max-w-[180px] animate-float" style={{ animationDelay: '1s', animationDuration: '5s' }}>
                <span className="text-2xl">⭐</span>
                <div>
                  <p className="text-xs font-body font-semibold text-forest-900">4.8/5 Rating</p>
                  <p className="text-[10px] text-forest-500 font-body">1,200+ Reviews</p>
                </div>
              </div>

              {/* Floating card 2 */}
              <div className="absolute -right-4 bottom-20 bg-forest-800 text-white rounded-2xl shadow-lg px-4 py-3 animate-float" style={{ animationDelay: '2s', animationDuration: '6s' }}>
                <p className="text-xs font-body font-medium">pH 8.5+</p>
                <p className="text-[10px] text-cream-200/70 font-body">Alkaline Water</p>
              </div>

              {/* Floating card 3 */}
              <div className="absolute left-4 -bottom-4 bg-cream-100 border border-cream-300 rounded-2xl shadow-lg px-4 py-3 animate-float" style={{ animationDelay: '0.5s', animationDuration: '8s' }}>
                <p className="text-xs font-body font-medium text-forest-800">🌿 100% Natural</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 animate-bounce">
        <span className="text-[10px] text-forest-400 tracking-widest uppercase font-body">Scroll</span>
        <svg className="w-4 h-4 text-forest-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M19 9l-7 7-7-7" />
        </svg>
      </div>
    </section>
  )
}
