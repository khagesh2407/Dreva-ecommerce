interface PageHeaderProps {
  label?: string
  title: string
  subtitle?: string
  dark?: boolean
}

export default function PageHeader({ label, title, subtitle, dark }: PageHeaderProps) {
  return (
    <section className={`py-16 px-4 sm:px-6 text-center relative overflow-hidden ${
      dark ? 'bg-peat text-white' : 'bg-cream-100 text-forest-900'
    }`}>
      <div className="absolute inset-0 opacity-[0.03]"
        style={{ backgroundImage: `url("data:image/svg+xml,%3Csvg width='40' height='40' viewBox='0 0 40 40' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M20 0L40 20L20 40L0 20Z' fill='%232d652b'/%3E%3C/svg%3E")`, backgroundSize: '40px 40px' }} />
      <div className="relative max-w-4xl mx-auto">
        {label && (
          <p className={`text-xs font-body font-medium tracking-[0.3em] uppercase mb-4 ${dark ? 'text-sage' : 'text-forest-500'}`}>
            {label}
          </p>
        )}
        <h1 className="font-display text-4xl sm:text-6xl font-light leading-tight mb-4">{title}</h1>
        {subtitle && (
          <p className={`font-body font-light text-lg leading-relaxed max-w-2xl mx-auto ${dark ? 'text-cream-200/70' : 'text-forest-600'}`}>
            {subtitle}
          </p>
        )}
      </div>
    </section>
  )
}
