const reasons = [
  {
    icon: '🌿',
    title: 'Purely Natural',
    desc: 'Every ingredient sourced from nature — no artificial additives, preservatives, or colours.',
  },
  {
    icon: '🏛️',
    title: 'FSSAI Certified',
    desc: 'All food products carry valid FSSAI certification, ensuring the highest safety standards.',
  },
  {
    icon: '🔬',
    title: 'Science-Backed',
    desc: 'Formulations grounded in nutritional science and dermatological research.',
  },
  {
    icon: '📦',
    title: 'Eco Packaging',
    desc: 'Sustainable, minimal packaging that respects the planet as much as your body.',
  },
  {
    icon: '🚚',
    title: 'Pan-India Delivery',
    desc: 'Free delivery on orders above ₹499. Express shipping available across all major cities.',
  },
  {
    icon: '💬',
    title: 'WhatsApp Support',
    desc: 'Real humans, real help — chat with us on WhatsApp for instant assistance.',
  },
]

export default function WhyChooseDreva() {
  return (
    <section className="section relative overflow-hidden" style={{ background: 'linear-gradient(135deg, #1a351a 0%, #2c3a20 50%, #1f401e 100%)' }}>
      {/* Texture */}
      <div className="absolute inset-0 opacity-5"
        style={{ backgroundImage: `url("data:image/svg+xml,%3Csvg width='40' height='40' viewBox='0 0 40 40' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M20 0L40 20L20 40L0 20Z' fill='%23ffffff' fill-opacity='1'/%3E%3C/svg%3E")`, backgroundSize: '40px 40px' }} />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 relative">
        <div className="text-center mb-14">
          <p className="text-xs font-body font-medium tracking-[0.3em] uppercase text-sage mb-3">
            The Dreva Difference
          </p>
          <h2 className="font-display text-4xl sm:text-5xl font-light text-white">
            Why Choose <em className="italic text-cream-300">Dreva</em>?
          </h2>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {reasons.map((r, i) => (
            <div key={r.title} className="group p-7 border border-white/10 rounded-sm hover:bg-white/5 transition-all duration-300 hover:border-white/20"
              style={{ animationDelay: `${i * 0.1}s` }}>
              <span className="text-3xl block mb-5">{r.icon}</span>
              <h3 className="font-display text-xl font-normal text-white mb-3">{r.title}</h3>
              <p className="text-sm font-body font-light text-cream-200/60 leading-relaxed">{r.desc}</p>
            </div>
          ))}
        </div>

        {/* Bottom stat strip */}
        <div className="mt-14 grid grid-cols-2 sm:grid-cols-4 gap-8 border-t border-white/10 pt-10">
          {[
            { num: '10,000+', label: 'Happy Customers' },
            { num: '12+', label: 'Premium Products' },
            { num: '4.8★', label: 'Avg. Rating' },
            { num: '3', label: 'Certifications' },
          ].map(stat => (
            <div key={stat.label} className="text-center">
              <p className="font-display text-3xl sm:text-4xl font-normal text-cream-300 mb-1">{stat.num}</p>
              <p className="text-xs font-body font-light text-cream-200/50 tracking-wide uppercase">{stat.label}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
