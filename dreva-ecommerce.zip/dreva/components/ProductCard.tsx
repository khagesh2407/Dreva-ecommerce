'use client'
import Link from 'next/link'
import Image from 'next/image'
import { Product } from '@/lib/data'
import { useCart } from '@/lib/cart-context'
import { useState } from 'react'

export default function ProductCard({ product }: { product: Product }) {
  const { addToCart } = useCart()
  const [added, setAdded] = useState(false)

  const handleAdd = (e: React.MouseEvent) => {
    e.preventDefault()
    addToCart(product)
    setAdded(true)
    setTimeout(() => setAdded(false), 1600)
  }

  const stars = Array.from({ length: 5 }, (_, i) => i < Math.round(product.rating))

  return (
    <Link href={`/products/${product.id}`} className="group block product-card relative bg-white rounded-sm overflow-hidden border border-cream-200">
      {/* Badge */}
      {product.badge && (
        <span className="absolute top-3 left-3 z-10 badge bg-forest-700 text-white">
          {product.badge}
        </span>
      )}

      {/* Image */}
      <div className="relative h-56 overflow-hidden bg-cream-100">
        <Image
          src={product.image}
          alt={product.name}
          fill
          className="object-cover group-hover:scale-105 transition-transform duration-600"
        />
        {product.originalPrice && (
          <span className="absolute top-3 right-3 badge bg-cream-400 text-bark-700">
            -{Math.round((1 - product.price / product.originalPrice) * 100)}%
          </span>
        )}
      </div>

      {/* Info */}
      <div className="p-4">
        <p className="text-[10px] font-body font-medium tracking-[0.2em] uppercase text-forest-400 mb-1 capitalize">
          {product.category}
        </p>
        <h3 className="font-display text-lg font-normal text-forest-900 leading-snug mb-1 group-hover:text-forest-700 transition-colors line-clamp-2">
          {product.name}
        </h3>
        <p className="text-xs font-body text-forest-500 font-light mb-3 line-clamp-2">
          {product.shortDesc}
        </p>

        {/* Stars */}
        <div className="flex items-center gap-1.5 mb-3">
          <div className="flex stars text-sm">
            {stars.map((filled, i) => (
              <span key={i} className={filled ? 'text-cream-500' : 'text-cream-300'}>★</span>
            ))}
          </div>
          <span className="text-[10px] text-forest-400 font-body">({product.reviews})</span>
        </div>

        {/* Price + CTA */}
        <div className="flex items-center justify-between">
          <div>
            <span className="font-body font-semibold text-forest-900 text-lg">₹{product.price}</span>
            {product.originalPrice && (
              <span className="text-sm text-forest-400 line-through ml-2 font-body">₹{product.originalPrice}</span>
            )}
          </div>
          <button
            onClick={handleAdd}
            className={`transition-all duration-200 px-3 py-2 text-xs font-body font-medium tracking-wide uppercase rounded-sm ${
              added
                ? 'bg-forest-600 text-white'
                : 'bg-forest-100 text-forest-700 hover:bg-forest-700 hover:text-white'
            }`}
          >
            {added ? '✓ Added' : '+ Cart'}
          </button>
        </div>
      </div>
    </Link>
  )
}
