import Link from 'next/link'
import Image from 'next/image'

const categories = [
  {
    id: 'superfood',
    title: 'Dreva Superfood',
    subtitle: 'Makhana, Dry Fruits & Seeds',
    description: 'Ancient superfoods, modern standards.',
    image: 'https://images.unsplash.com/photo-1604977042946-1eecc30f269e?w=600&q=80',
    color: 'bg-forest-100',
    accent: 'text-forest-800',
    cta: 'Explore Superfoods',
    badge: '🌰',
  },
  {
    id: 'water',
    title: 'Dreva Alkaline Water',
    subtitle: 'pH 8+ Mineral Hydration',
    description: 'Purity elevated. Hydration perfected.',
    image: 'https://images.unsplash.com/photo-1559839914-17aae19cec71?w=600&q=80',
    color: 'bg-blue-50',
    accent: 'text-blue-900',
    cta: 'Shop Water',
    badge: '💧',
  },
  {
    id: 'skincare',
    title: 'Dreva Skincare',
    subtitle: 'Natural, Effective Solutions',
    description: 'Botanicals meet science.',
    image: 'https://images.unsplash.com/photo-1620916566398-39f1143ab7be?w=600&q=80',
    color: 'bg-rose-50',
    accent: 'text-rose-900',
    cta: 'Explore Skincare',
    badge: '✨',
  },
]

export default function Categories() {
  return (
    <section className="section bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        {/* Header */}
        <div className="text-center mb-14">
          <p className="text-xs font-body font-medium tracking-[0.3em] uppercase text-forest-500 mb-3">Our Collections</p>
          <h2 className="font-display text-4xl sm:text-5xl font-light text-forest-900">
            Three Pillars of Wellness
          </h2>
        </div>

        {/* Grid */}
        <div className="grid md:grid-cols-3 gap-6">
          {categories.map((cat, i) => (
            <Link key={cat.id} href={`/shop?cat=${cat.id}`}
              className={`group relative overflow-hidden rounded-sm product-card ${cat.color} block`}
              style={{ animationDelay: `${i * 0.1}s` }}>
              {/* Image */}
              <div className="relative h-64 overflow-hidden">
                <Image
                  src={cat.image}
                  alt={cat.title}
                  fill
                  className="object-cover group-hover:scale-105 transition-transform duration-700"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent" />
                <span className="absolute top-4 left-4 text-3xl">{cat.badge}</span>
              </div>

              {/* Content */}
              <div className="p-6">
                <p className="text-[10px] font-body font-medium tracking-[0.25em] uppercase text-forest-500 mb-1">
                  {cat.subtitle}
                </p>
                <h3 className={`font-display text-2xl font-normal ${cat.accent} mb-2`}>
                  {cat.title}
                </h3>
                <p className="text-sm font-body font-light text-forest-600 mb-4">{cat.description}</p>
                <span className="inline-flex items-center gap-2 text-xs font-body font-medium tracking-widest uppercase text-forest-700 group-hover:gap-3 transition-all">
                  {cat.cta}
                  <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
                  </svg>
                </span>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  )
}
