import Link from 'next/link'

export default function Footer() {
  return (
    <footer className="bg-peat text-cream-200 pt-16 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 mb-12">
          {/* Brand */}
          <div className="lg:col-span-1">
            <div className="flex items-center gap-2 mb-4">
              <span className="text-2xl">🌿</span>
              <div>
                <span className="font-display text-2xl text-white tracking-wide">Dreva</span>
                <span className="block text-[9px] text-cream-300/60 tracking-[0.2em] uppercase font-body mt-0.5">by ZK Elite Pvt. Ltd.</span>
              </div>
            </div>
            <p className="text-sm text-cream-200/70 leading-relaxed font-body font-light mb-5">
              Rooted in Nature. Anchored in Wisdom. Premium wellness products for every home.
            </p>
            <div className="flex gap-3">
              {['Instagram', 'WhatsApp', 'YouTube'].map(s => (
                <a key={s} href="#" className="w-9 h-9 rounded-full bg-forest-800/50 hover:bg-forest-700 transition-colors flex items-center justify-center text-xs text-cream-200/70 hover:text-white">
                  {s[0]}
                </a>
              ))}
            </div>
          </div>

          {/* Shop */}
          <div>
            <h4 className="font-body text-xs font-semibold tracking-[0.2em] uppercase text-cream-300/60 mb-5">Shop</h4>
            <ul className="space-y-2.5">
              {[
                ['Superfood Makhana', '/shop?cat=superfood'],
                ['Dry Fruits', '/shop?cat=superfood'],
                ['Alkaline Water', '/shop?cat=water'],
                ['Natural Skincare', '/shop?cat=skincare'],
                ['All Products', '/shop'],
              ].map(([label, href]) => (
                <li key={label}>
                  <Link href={href} className="text-sm text-cream-200/70 hover:text-white transition-colors font-body">{label}</Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Company */}
          <div>
            <h4 className="font-body text-xs font-semibold tracking-[0.2em] uppercase text-cream-300/60 mb-5">Company</h4>
            <ul className="space-y-2.5">
              {[
                ['About Dreva', '/about'],
                ['Wellness Blog', '/blog'],
                ['Contact Us', '/contact'],
                ['Privacy Policy', '/privacy'],
                ['Terms of Service', '/terms'],
              ].map(([label, href]) => (
                <li key={label}>
                  <Link href={href} className="text-sm text-cream-200/70 hover:text-white transition-colors font-body">{label}</Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-body text-xs font-semibold tracking-[0.2em] uppercase text-cream-300/60 mb-5">Get in Touch</h4>
            <ul className="space-y-3">
              <li className="flex gap-3 text-sm text-cream-200/70 font-body">
                <span className="mt-0.5 text-sage">📍</span>
                <span>Raipur, Chhattisgarh<br />India — 492001</span>
              </li>
              <li>
                <a href="mailto:support@zkelite.store" className="flex gap-3 text-sm text-cream-200/70 hover:text-white transition-colors font-body">
                  <span className="text-sage">✉️</span> support@zkelite.store
                </a>
              </li>
              <li>
                <a href="https://wa.me/918224021324" className="flex gap-3 text-sm text-cream-200/70 hover:text-white transition-colors font-body">
                  <span className="text-sage">💬</span> +91 82240 21324
                </a>
              </li>
            </ul>
            <div className="mt-5 flex gap-2 flex-wrap">
              {['FSSAI', 'MSME', 'Startup India'].map(cert => (
                <span key={cert} className="text-[10px] border border-cream-200/20 text-cream-200/50 px-2 py-1 rounded-sm font-body tracking-wide">
                  {cert}
                </span>
              ))}
            </div>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="border-t border-cream-200/10 pt-6 flex flex-col sm:flex-row justify-between items-center gap-3">
          <p className="text-xs text-cream-200/40 font-body">
            © 2026 ZK Elite Pvt. Ltd. All Rights Reserved.
          </p>
          <div className="flex gap-4">
            {['Visa', 'Mastercard', 'UPI', 'Razorpay'].map(p => (
              <span key={p} className="text-[10px] text-cream-200/40 font-body">{p}</span>
            ))}
          </div>
        </div>
      </div>
    </footer>
  )
}
