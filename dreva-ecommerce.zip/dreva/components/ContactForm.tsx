'use client'
import { useState } from 'react'

export default function ContactForm() {
  const [form, setForm] = useState({ name: '', email: '', subject: '', message: '' })
  const [submitted, setSubmitted] = useState(false)
  const [loading, setLoading] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    await new Promise(r => setTimeout(r, 800))
    setSubmitted(true)
    setLoading(false)
  }

  if (submitted) {
    return (
      <div className="text-center py-12">
        <span className="text-5xl block mb-4">🌿</span>
        <h3 className="font-display text-3xl font-light text-forest-900 mb-2">Message Received!</h3>
        <p className="font-body text-forest-600 font-light">We'll get back to you within 24 hours.</p>
      </div>
    )
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-5">
      <div className="grid sm:grid-cols-2 gap-5">
        <div>
          <label className="block text-xs font-body font-medium tracking-widest uppercase text-forest-600 mb-2">Name</label>
          <input type="text" required placeholder="Your name" value={form.name}
            onChange={e => setForm({ ...form, name: e.target.value })}
            className="input-field" />
        </div>
        <div>
          <label className="block text-xs font-body font-medium tracking-widest uppercase text-forest-600 mb-2">Email</label>
          <input type="email" required placeholder="your@email.com" value={form.email}
            onChange={e => setForm({ ...form, email: e.target.value })}
            className="input-field" />
        </div>
      </div>
      <div>
        <label className="block text-xs font-body font-medium tracking-widest uppercase text-forest-600 mb-2">Subject</label>
        <input type="text" required placeholder="How can we help?" value={form.subject}
          onChange={e => setForm({ ...form, subject: e.target.value })}
          className="input-field" />
      </div>
      <div>
        <label className="block text-xs font-body font-medium tracking-widest uppercase text-forest-600 mb-2">Message</label>
        <textarea required rows={5} placeholder="Tell us more..." value={form.message}
          onChange={e => setForm({ ...form, message: e.target.value })}
          className="input-field resize-none" />
      </div>
      <button type="submit" disabled={loading} className="btn-primary w-full sm:w-auto">
        {loading ? 'Sending...' : 'Send Message'}
      </button>
    </form>
  )
}
